export class Utilizador {
    id: number;
    nome: string;
    sobreNome: string;
    email: string;
}

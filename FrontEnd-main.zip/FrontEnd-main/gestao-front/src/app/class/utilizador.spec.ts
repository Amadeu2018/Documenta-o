import { Utilizador } from './utilizador';

describe('Utilizador', () => {
  it('should create an instance', () => {
    expect(new Utilizador()).toBeTruthy();
  });
});
